#ifndef LUABINS_LUAHEADERS_H_
#define LUABINS_LUAHEADERS_H_

#if defined (__cplusplus) && !defined (LUABINS_LUABUILTASCPP)
extern "C" {
#endif

#include <lua.h>
#include <lauxlib.h>
#if defined (__cplusplus) && !defined (LUABINS_LUABUILTASCPP)
}
#endif

#endif /* LUABINS_LUAHEADERS_H_ */
