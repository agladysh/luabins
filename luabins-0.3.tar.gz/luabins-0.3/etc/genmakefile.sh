#! /bin/bash
lua ~/projects/genmakefile/src/genmakefile.lua <etc/Makefile.luabins.template >Makefile
