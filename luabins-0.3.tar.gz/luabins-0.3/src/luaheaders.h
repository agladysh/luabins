#ifndef LUABINS_LUAHEADERS_H_INCLUDED_
#define LUABINS_LUAHEADERS_H_INCLUDED_

#if defined (__cplusplus) && !defined (LUABINS_LUABUILTASCPP)
extern "C" {
#endif

#include <lua.h>
#include <lauxlib.h>
#if defined (__cplusplus) && !defined (LUABINS_LUABUILTASCPP)
}
#endif

#endif /* LUABINS_LUAHEADERS_H_INCLUDED_ */
